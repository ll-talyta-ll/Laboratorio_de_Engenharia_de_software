(function (win, doc){
    "use strict";

    alert('oi')
})(window, document);
